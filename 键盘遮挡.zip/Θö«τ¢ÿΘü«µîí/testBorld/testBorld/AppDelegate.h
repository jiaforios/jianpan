//
//  AppDelegate.h
//  testBorld
//
//  Created by qlh on 17/2/16.
//  Copyright © 2017年 Qlh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

