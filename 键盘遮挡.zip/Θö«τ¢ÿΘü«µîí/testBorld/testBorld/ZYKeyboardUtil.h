//
//  ZYKeyboardUtil.h
//  ZYKeyboardUtil
//
//  Created by lzy on 15/12/26.
//  Copyright © 2015年 lzy . All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

#define  WeakSelf __weak typeof(self) weakSelf = self
#define KeyboardUtilHelper(obj,topMargin,...) obj = [[ZYKeyboardUtil alloc] initWithKeyboardTopMargin:topMargin];\
       WeakSelf;\
[obj setAnimateWhenKeyboardAppearAutomaticAnimBlock:^(ZYKeyboardUtil *keyboardUtil) {\
[keyboardUtil adaptiveViewHandleWithController:weakSelf adaptiveView:__VA_ARGS__];\
}]


static CGFloat const DURATION_ANIMATION = 0.5f;

typedef enum {
    KeyboardActionDefault,
    KeyboardActionShow,
    KeyboardActionHide
}KeyboardAction;

@protocol KeyboardUtilProtocol <NSObject>
- (void)adaptiveViewHandleWithAdaptiveView:(UIView *)adaptiveView, ...NS_REQUIRES_NIL_TERMINATION;
- (void)adaptiveViewHandleWithController:(UIViewController *)viewController adaptiveView:(UIView *)adaptiveView, ...NS_REQUIRES_NIL_TERMINATION;
@end


#pragma mark - KeyboardInfo(model)
@interface KeyboardInfo : NSObject
@property (assign, nonatomic) CGFloat animationDuration;
@property (assign, nonatomic) CGRect frameBegin;
@property (assign, nonatomic) CGRect frameEnd;
@property (assign, nonatomic) CGFloat heightIncrement;
@property (assign, nonatomic) KeyboardAction action;
@property (assign, nonatomic) BOOL isSameAction;

- (void)fillKeyboardInfoWithDuration:(CGFloat)duration frameBegin:(CGRect)frameBegin frameEnd:(CGRect)frameEnd heightIncrement:(CGFloat)heightIncrement action:(KeyboardAction)action isSameAction:(BOOL)isSameAction;
@end


#pragma mark - ZYKeyboardUtil
@interface ZYKeyboardUtil : NSObject<KeyboardUtilProtocol>

//Block
typedef void (^animateWhenKeyboardAppearBlock)(int appearPostIndex, CGRect keyboardRect, CGFloat keyboardHeight, CGFloat keyboardHeightIncrement);
typedef void (^animateWhenKeyboardDisappearBlock)(CGFloat keyboardHeight);
typedef void (^printKeyboardInfoBlock)(ZYKeyboardUtil *keyboardUtil, KeyboardInfo *keyboardInfo);
typedef void (^animateWhenKeyboardAppearAutomaticAnimBlock)(ZYKeyboardUtil *keyboardUtil);

@property (assign, nonatomic) CGFloat keyboardTopMargin;

- (instancetype)initWithKeyboardTopMargin:(CGFloat)keyboardTopMargin;

- (void)setAnimateWhenKeyboardAppearBlock:(animateWhenKeyboardAppearBlock)animateWhenKeyboardAppearBlock;
- (void)setAnimateWhenKeyboardAppearAutomaticAnimBlock:(animateWhenKeyboardAppearAutomaticAnimBlock)animateWhenKeyboardAppearAutomaticAnimBlock;
- (void)setAnimateWhenKeyboardDisappearBlock:(animateWhenKeyboardDisappearBlock)animateWhenKeyboardDisappearBlock;
- (void)setPrintKeyboardInfoBlock:(printKeyboardInfoBlock)printKeyboardInfoBlock;


@end


#pragma mark - UIView+Utils
@interface UIView (Utils)
- (void)findControllerWithResultController:(UIViewController **)resultController;
@end

